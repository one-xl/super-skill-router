---
name: super-skill-router
description: Global entrypoint for Super Skill Router. Use for non-trivial AI Agent tasks that may benefit from selecting, combining, acquiring from skills.sh, or maintaining Skills through progressive routing instead of reading all Skill files at once.
---

# Super Skill Router Global Entrypoint

This is the only Codex-discoverable entrypoint for Super Skill Router.

## Resolve Roots

Set:

```text
SUPER_SKILL_ROOT = C:/Users/a1028/.codex/vendor/super-skill-router/skills
```

Set `BUSINESS_SKILL_ROOT` with this priority:

1. If the current workspace has a `skills/` directory, use that.
2. Otherwise use `SUPER_SKILL_ROOT` for built-in examples.

## Continue

Read:

```text
SUPER_SKILL_ROOT/_super-skill/SKILL.md
SUPER_SKILL_ROOT/_super-skill/ROUTER.md
```

Then follow the router rules:

- Read `CATEGORY_INDEX.md` first.
- Read `SKILL_POLICY.md` before installing, updating, or using auxiliary Skills.
- Read `PROJECT_PROFILE.md` for code, build, deployment, or repository-structure tasks.
- Read `ROUTING_CONFIDENCE.md` when category or subcategory choice is uncertain.
- Read only candidate category tags.
- Read only candidate subcategory tags.
- Read auxiliary Skill rules for coding, review, refactoring, testing, or implementation tasks.
- Use `karpathy-guidelines` as the default auxiliary Skill for coding tasks when it is installed.
- Read full `SKILL.md` only when the tag says it is needed.
- Use `ROUTING_TRACE.md` only when the user asks why a Skill was selected or asks for routing details.
- Use `SKILL_LOCK.md` rules after confirmed external Skill installation or update.
- Use `HEALTH_CHECK.md` only when the user asks to validate, audit, or repair Skill structure.
- Use `skills.sh` as the default external Skill discovery and installation source.
- Generate Skill Install Proposal when a suitable external Skill exists but is not installed locally.
- Generate Skill Update Proposal when no suitable Skill exists or reusable experience appears.
- Do not download, install, update, or overwrite Skill files unless the user explicitly confirms.
